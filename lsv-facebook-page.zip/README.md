# LSV Facebook Page

A responsive landing page with the LSV and cabbage family brand artwork,
local Manrope and Kantumruy fonts, and QR codes for:

- Nut Samphois: https://www.facebook.com/nutsamphois
- LSV Industry: https://www.facebook.com/lsvindustry

Open index.html directly, or start a local preview from this folder:

    python -m http.server 8000 --bind 127.0.0.1

Visit http://127.0.0.1:8000/ in your browser.

index.html, style.css, and script.js contain the page. Keep the two PNG
brand images and the assets folder alongside them. All fonts and QR assets
are local. The QR generator reads the exact destination from each Facebook
button. The PNG QR codes also work with JavaScript disabled.

Font and QR-generator licenses are included alongside their assets.
